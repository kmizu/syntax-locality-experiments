# Syntax locality experiment source snapshot

This directory contains a byte-identical, explicitly selected snapshot of the isolated `feat/full-program-parse-generate` checkout. It includes the original scope-reading tasks and the new complete-program `source_to_ast` / `ast_to_source` tasks. The new source was implemented but had no passing post-change full test when this snapshot was captured; its remote verification must be assessed from the actual CI result.

The local frozen reading main uses its own earlier source and protocol. This snapshot does not replace that source, change its frozen plan, or convert its scope-reading results into full-program parsing results. The new P2 pilot is a separate exploratory protocol; no live P2 result is included.

## Verify the source

Use Windows, JDK 21, Scala 3.3.8 and sbt 1.10.7. From this directory, run the repository's unmodified required command:

```powershell
$env:SYNTAX_JAVA_HOME = $env:JAVA_HOME # an installed JDK 21
./scripts/sbt.ps1 test
```

In this public repository the working directory is `experiment/`. The wrapper invokes `bin/java.exe`, so it requires a Windows runner. It downloads the sbt 1.10.7 launcher on a fresh checkout; sbt then obtains the build tool, compiler and Scala standard libraries. The application has no external runtime libraries beyond Scala's standard library and JDK APIs.

Expected successful output includes **28 core tests**, **19 named bench suites**, and **12 named preflight tests** within the bench preflight suite. The tests use synthetic mocks and JDK HTTP servers bound to loopback. They do not require API credentials and do not send requests to a real model endpoint. A passing build verifies tested implementation behavior; it does not measure a model's parsing or generation accuracy.

## Included files and provenance

[`source-manifest.json`](source-manifest.json) records every copied file's SHA-256 and byte count, the originating base commit, the dirty feature state, the implementation source hash and a checkpoint of the complete selected snapshot. The source and test trees, build definition, wrapper, four JSON configurations and four technical documents were selected explicitly. None of the copied source bytes were edited for publication.

The repository's `.env`, credentials, personal instruction files, Git internals, caches, compiled targets, live run artifacts, verification logs and user history are excluded. No live execution is invoked by the verification command. Any later real model run still requires explicit `--execute`, numerical generation/HTTP/token limits, saved provenance and separate reporting.

Read the [experiment specification](scala3-syntax-locality-icl-experiment.md), [protocol](docs/protocol.md), [limitations](docs/limitations.md) and [full-program extension](docs/full-program-structures.md) for the task contracts and interpretation boundaries. The included technical documents describe their capture-time state; subsequent remote test evidence should be reported separately.
