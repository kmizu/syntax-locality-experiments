package publication

import java.nio.charset.StandardCharsets.UTF_8
import java.nio.file.{Files, LinkOption, Path, StandardCopyOption}
import java.security.MessageDigest
import scala.jdk.CollectionConverters.*

/** Offline presentation of persisted grading/report artifacts. No model calls or resampling. */
object HtmlReport:
  private val styles = Vector("braces", "generic_end", "typed_end", "named_end", "padded_end")
  private val labels = Map("braces" -> "A · braces", "generic_end" -> "B · generic end",
    "typed_end" -> "C · typed end", "named_end" -> "D · named end", "padded_end" -> "E · padded end")
  private val requiredFiles = Vector("summary.csv", "paired-comparisons.csv", "errors.csv", "report.md", "protocol.json")
  private val dimensions = Vector("task", "view", "style", "lexical_regime", "depth", "filler")
  private val additive = Vector("planned", "dispatched", "terminal", "model_evaluable", "correct",
    "infrastructure_missing", "not_dispatched", "incomplete", "refusal")

  final case class Row(values: Map[String, String]):
    def apply(key: String): String = values.getOrElse(key, throw IllegalArgumentException(s"Missing CSV column: $key"))
    def number(key: String): Long =
      val value = apply(key)
      require(value.matches("[0-9]+"), s"Expected a non-negative integer in $key, received $value")
      value.toLong

  final case class Run(name: String, summary: Vector[Row], comparisons: Vector[Row], errors: Vector[Row], protocol: String):
    val total: Row =
      val totals = summary.filter(r => dimensions.forall(k => r(k) == "ALL"))
      require(totals.size == 1, s"$name must have exactly one overall summary")
      totals.head
    val leaves: Vector[Row] = summary.filter(r => dimensions.forall(k => r(k) != "ALL"))
    require(leaves.nonEmpty, s"$name has no disjoint summary cells")
    require(leaves.map(r => dimensions.map(r(_))).distinct.size == leaves.size, s"$name has duplicate summary cells")
    require(leaves.forall(r => styles.contains(r("style"))), s"$name contains an unsupported style")
    additive.foreach { key =>
      require(leaves.map(_.number(key)).sum == total.number(key), s"$name leaf/aggregate $key mismatch")
    }
    summary.foreach { row =>
      require(row.number("correct") <= row.number("model_evaluable"), s"$name correct exceeds evaluable")
      require(row.number("model_evaluable") <= row.number("dispatched"), s"$name evaluable exceeds dispatched")
      require(row.number("terminal") <= row.number("planned"), s"$name terminal exceeds planned")
      require(row.number("dispatched") <= row.number("planned"), s"$name dispatched exceeds planned")
    }
    require(errors.size.toLong == total.number("planned") - total.number("correct"),
      s"$name error rows must preserve every non-correct planned trial, including missing/unexecuted trials")
    require(errors.map(_("trial_id")).distinct.size == errors.size, s"$name has duplicate error trial IDs")
    def wholeStyle(task: String, view: String, style: String): Row =
      val found = summary.filter(r => r("task") == task && r("view") == view && r("style") == style &&
        Vector("lexical_regime", "depth", "filler").forall(k => r(k) == "ALL"))
      require(found.size == 1, s"Missing or duplicate persisted $name/$task/$view/$style summary")
      found.head
    def sum(task: String, view: String, style: String, depth: String, field: String): Long =
      leaves.filter(r => r("task") == task && r("view") == view && r("style") == style && r("depth") == depth)
        .map(_.number(field)).sum

  def main(args: Array[String]): Unit =
    require(Runtime.version().feature() == 21, "JDK 21 is required")
    require(args.length <= 2, "Usage: HtmlReport [data-directory] [site-directory]")
    val input = Path.of(args.headOption.getOrElse("data")).toAbsolutePath.normalize()
    val output = Path.of(args.lift(1).getOrElse("site")).toAbsolutePath.normalize()
    require(Files.isDirectory(input), s"Missing publication data directory: $input")
    require(!input.startsWith(output) && !output.startsWith(input), "Input and output directories must not overlap")
    val pilot = readRun(input, "pilot")
    val main = readRun(input, "main")
    require(pilot.total.number("planned") == 1800 && pilot.total.number("terminal") == 1800 &&
      pilot.total.number("model_evaluable") == 1800 && pilot.total.number("correct") == 1622,
      "This report requires the complete original P1 pilot; do not pool changed protocols")
    require(main.total.number("planned") == 5120, "Expected the original frozen 5,120-trial main plan")
    require(protocolScalar(pilot.protocol, "protocolHash") ==
      "f7dd15dd3c44b507506e123517157926a35a53b52c1d4aab278664f512a1e182", "Unexpected original P1 protocol")
    require(protocolScalar(main.protocol, "protocolHash") ==
      "f57aadd6b497ff6d05715753dd59802be050dce8ec5706ff41216721515e6f4a", "Unexpected frozen main protocol")
    require(main.comparisons.forall(_("ci_status") == "not_computed"),
      "This interrupted-snapshot report requires uncomputed main CIs; update the interpretation for a completed run")
    require(pilot.wholeStyle("ast_to_source", "complete", "named_end").number("correct") == 71,
      "Unexpected original P1 generation result")
    val namedGeneration = pilot.wholeStyle("ast_to_source", "complete", "named_end")
    require(namedGeneration.number("invalid_generated_syntax") == 0 &&
      namedGeneration.number("valid_syntax_wrong_ast") == 1 && namedGeneration.number("syntax_evaluable_trials") == 72,
      "Unexpected original P1 named-end syntax/AST result")
    require(pilot.sum("ast_to_source", "complete", "named_end", "8", "correct") == 24 &&
      pilot.sum("ast_to_source", "complete", "generic_end", "8", "correct") == 0,
      "Unexpected original P1 depth-8 result")
    val artifacts = publicFiles(input)
    Files.createDirectories(output)
    val copiedData = output.resolve("data")
    Files.createDirectories(copiedData)
    artifacts.foreach { relative =>
      val target = copiedData.resolve(relative).normalize()
      require(target.startsWith(copiedData), "Artifact path escaped the output data directory")
      Files.createDirectories(target.getParent)
      Files.copy(input.resolve(relative), target, StandardCopyOption.REPLACE_EXISTING)
      require(sha256(input.resolve(relative)) == sha256(target), s"Copied artifact hash mismatch: $relative")
    }
    val hashes = artifacts.map(p => p.toString.replace('\\', '/') -> sha256(input.resolve(p)))
    val fingerprint = hashText(hashes.map((name, hash) => s"$name\t$hash\n").mkString)
    val workflowUrl = sys.env.get("SYNTAX_REPORT_WORKFLOW_URL").filter(_.nonEmpty)
    workflowUrl.foreach(url => require(url.matches("https://github\\.com/[^/]+/[^/]+/actions/runs/[0-9]+(?:/attempts/[0-9]+)?"),
      "SYNTAX_REPORT_WORKFLOW_URL must identify a GitHub Actions workflow run"))
    val p2Verified = sys.env.get("SYNTAX_P2_TEST_VERIFIED").contains("true")
    require(!p2Verified || workflowUrl.nonEmpty, "Verified P2 test status requires its workflow-run evidence URL")
    val buildProvenance = s"""{"schemaVersion":1,"p2PostChangeFullTestVerified":$p2Verified,"workflowRunUrl":${workflowUrl.map(js).getOrElse("null")},"inputManifestSha256":${js(fingerprint)},"note":"The verified flag is supplied by the publication workflow only after its separate full experiment-test job succeeds. This is build verification, not P2 model measurement."}
"""
    Files.writeString(output.resolve("build-provenance.json"), buildProvenance, UTF_8)
    val html = render(pilot, main, hashes, fingerprint, input, p2Verified, workflowUrl)
    Files.writeString(output.resolve("index.html"), html, UTF_8)
    println(s"Generated ${output.resolve("index.html")} from ${artifacts.size} saved public artifacts")
    println(s"Input manifest SHA-256: $fingerprint")
    println(s"P1: ${pilot.total.number("correct")}/${pilot.total.number("model_evaluable")}; " +
      s"main: ${main.total.number("terminal")}/${main.total.number("planned")} terminal dispositions")

  private def readRun(root: Path, name: String): Run =
    val dir = root.resolve(name)
    requiredFiles.foreach(f => require(Files.isRegularFile(dir.resolve(f), LinkOption.NOFOLLOW_LINKS), s"Missing $name/$f"))
    Run(name, readCsv(dir.resolve("summary.csv")), readCsv(dir.resolve("paired-comparisons.csv")),
      readCsv(dir.resolve("errors.csv")), Files.readString(dir.resolve("protocol.json"), UTF_8))

  private def publicFiles(root: Path): Vector[Path] =
    val stream = Files.walk(root)
    try
      val all = stream.iterator().asScala.toVector
      require(!all.exists(Files.isSymbolicLink(_)), "Public data may not contain symbolic links")
      val files = all.filter(p => Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS)).map(root.relativize(_))
      require(!files.exists(p => p.iterator().asScala.exists(_.toString.startsWith("."))), "Hidden public artifacts are forbidden")
      files.sortBy(_.toString.replace('\\', '/'))
    finally stream.close()

  /** Strict RFC-style CSV handling, including embedded line breaks and doubled quotes. */
  private def readCsv(path: Path): Vector[Row] =
    val raw = Files.readString(path, UTF_8).stripPrefix("\ufeff")
    val rows = Vector.newBuilder[Vector[String]]
    val fields = Vector.newBuilder[String]
    val field = new StringBuilder
    var state = 0 // 0: unquoted, 1: quoted, 2: closed quote
    var i = 0
    var touched = false
    var rowFields = 0
    def endField(): Unit =
      fields += field.toString
      field.clear()
      state = 0
      rowFields += 1
    def endRow(): Unit =
      endField()
      rows += fields.result()
      fields.clear()
      touched = false
      rowFields = 0
    while i < raw.length do
      val c = raw.charAt(i)
      if state == 1 then
        if c == '"' then
          if i + 1 < raw.length && raw.charAt(i + 1) == '"' then
            field.append('"')
            i += 1
          else state = 2
        else field.append(c)
        touched = true
      else
        c match
          case '"' =>
            require(state == 0 && field.isEmpty, s"Unexpected CSV quote in $path at character $i")
            state = 1
            touched = true
          case ',' => endField(); touched = true
          case '\r' | '\n' =>
            endRow()
            if c == '\r' && i + 1 < raw.length && raw.charAt(i + 1) == '\n' then i += 1
          case _ =>
            require(state != 2, s"Characters after closing CSV quote in $path at character $i")
            field.append(c)
            touched = true
      i += 1
    require(state != 1, s"Unclosed CSV quote in $path")
    if touched || field.nonEmpty || rowFields > 0 then endRow()
    val parsed = rows.result()
    require(parsed.nonEmpty && parsed.head.nonEmpty && parsed.head.forall(_.nonEmpty), s"Missing CSV header in $path")
    val header = parsed.head
    require(header.distinct.size == header.size, s"Duplicate CSV header in $path")
    parsed.tail.zipWithIndex.map { (row, index) =>
      require(row.size == header.size, s"CSV row ${index + 2} has ${row.size} columns; expected ${header.size} in $path")
      Row(header.zip(row).toMap)
    }

  private def sha256(path: Path): String =
    val digest = MessageDigest.getInstance("SHA-256")
    val stream = Files.newInputStream(path)
    try
      val buffer = new Array[Byte](65536)
      var count = stream.read(buffer)
      while count >= 0 do
        if count > 0 then digest.update(buffer, 0, count)
        count = stream.read(buffer)
    finally stream.close()
    digest.digest().map(b => f"${b & 0xff}%02x").mkString

  private def hashText(text: String): String =
    MessageDigest.getInstance("SHA-256").digest(text.getBytes(UTF_8)).map(b => f"${b & 0xff}%02x").mkString
  private def h(value: String): String = value.flatMap {
    case '&' => "&amp;"
    case '<' => "&lt;"
    case '>' => "&gt;"
    case '"' => "&quot;"
    case '\'' => "&#39;"
    case c => c.toString
  }
  private def js(value: String): String = "\"" + value.flatMap {
    case '"' => "\\\""
    case '\\' => "\\\\"
    case '\n' => "\\n"
    case '\r' => "\\r"
    case '\t' => "\\t"
    case '<' => "\\u003c"
    case '&' => "\\u0026"
    case c if c < ' ' || c == '\u2028' || c == '\u2029' => f"\\u${c.toInt}%04x"
    case c => c.toString
  } + "\""
  private def comma(value: Long): String = value.toString.reverse.grouped(3).mkString(",").reverse
  private def percent(correct: Long, evaluable: Long): String =
    if evaluable == 0 then "NA" else f"${correct.toDouble * 100.0 / evaluable}%.3f%%"
  private def link(path: String, label: String): String = s"<a href=\"data/${h(path)}\" download>${h(label)}</a>"
  private def source(run: String, file: String, label: String): String = link(s"$run/$file", label)
  private def detail(title: String, body: String): String = s"<details><summary>${h(title)}</summary>$body</details>"
  private def protocolScalar(protocol: String, key: String): String =
    val pattern = ("\\\"" + java.util.regex.Pattern.quote(key) + "\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"").r
    val values = pattern.findAllMatchIn(protocol).map(_.group(1)).toVector
    require(values.size == 1, s"Expected exactly one protocol string field $key")
    values.head

  private def render(pilot: Run, main: Run, hashes: Vector[(String, String)], fingerprint: String, input: Path,
    p2Verified: Boolean, workflowUrl: Option[String]): String =
    val named = pilot.wholeStyle("ast_to_source", "complete", "named_end")
    val generic = pilot.wholeStyle("ast_to_source", "complete", "generic_end")
    val terminal = main.total.number("terminal")
    val planned = main.total.number("planned")
    val unfinished = planned - terminal
    val mainComplete = terminal == planned
    val status = if mainComplete then "全試行の処置を保存済み" else "本実験は中断したスナップショット"
    val supportRecovery = "supporting/main-zero-http-recovery.json"
    val reservation =
      if Files.isRegularFile(input.resolve(supportRecovery)) then
        val text = Files.readString(input.resolve(supportRecovery), UTF_8)
        if "(?s).*\\b14131\\b.*".r.matches(text) then
          s"未解決の予約 <strong>14,131 tokens</strong> を保持。結果不明の生成は再送していない。${link(supportRecovery, "復旧・使用量の証跡")}" 
        else s"未解決使用量はゼロに置き換えていない。${link(supportRecovery, "復旧・使用量の証跡")}" 
      else "未解決使用量はゼロに置き換えていない。使用量の詳細は保存済みレポートを参照。"
    val mainNotice = s"$status。保存済み処置 ${comma(terminal)} / ${comma(planned)}、" +
      s"評価可能な応答 ${comma(main.total.number("model_evaluable"))}、正解 ${comma(main.total.number("correct"))}。" +
      s"${comma(unfinished)} 件は terminal 記録なし。main の信頼区間は未計算。"
    val p2VerificationText =
      if p2Verified then
        s"実装追加済み。変更後の実験コードの全テストは、この公開 workflow の別 job で成功。" +
          s"<a href=\"${h(workflowUrl.get)}\">実際の GitHub Actions 実行</a>。" +
          "これは実装の検証で、モデルの測定ではない。mock も live も未実行で、成功率・差・CI はない。"
      else
        "実装追加済み。変更後の全テストは環境の build cache / network 制限で未完了。" +
          "mock も live も未実行で、成功率・差・CI はない。"
    val dataJs = Vector(pilot, main).map { run =>
      val keys = dimensions ++ additive
      val rows = run.leaves.map(row => keys.map(k => js(k) + ":" + js(row(k))).mkString("{", ",", "}")).mkString("[", ",", "]")
      js(run.name) + ":" + rows
    }.mkString("{", ",", "}")
    val artifacts = hashes.map { (path, hash) =>
      s"<tr><td>${link(path, path)}</td><td><code class=\"hash\">$hash</code></td></tr>"
    }.mkString
    val comparisons = pilot.comparisons.filter(r => r("treatment") == "named_end" && r("baseline") == "generic_end" &&
      ((r("task") == "ast_to_source" && r("view") == "complete") ||
       (r("task") != "ast_to_source" && r("view") == "after_close")))
    require(comparisons.size == 3, "Expected three saved P1 named_end/generic_end contrasts")
    val comparisonRows = comparisons.sortBy(r => r("task")).map { r =>
      val interval = if r("ci_status") == "computed" || r("ci_status") == "degenerate" then
        s"[${h(r("ci_lower_pp"))}, ${h(r("ci_upper_pp"))}]" else "未計算"
      s"<tr><td><code>${h(r("task"))}</code><br><span class=\"muted\">${h(r("view"))}</span></td>" +
        s"<td>${h(r("matched_families_available"))}/${h(r("matched_families_planned"))}</td>" +
        s"<td>+${h(r("difference_percentage_points"))} pp</td><td>$interval</td><td>${h(r("ci_status"))}</td></tr>"
    }.mkString
    val initialRows = styles.map { style =>
      val r = pilot.wholeStyle("ast_to_source", "complete", style)
      tableRow(style, r.number("correct"), r.number("model_evaluable"), r.number("planned"),
        r.number("dispatched"), r.number("terminal"), r.number("infrastructure_missing"), r.number("not_dispatched"))
    }.mkString
    val depthRows = styles.map { style =>
      val cells = Vector("2", "4", "8").map { depth =>
        val correct = pilot.sum("ast_to_source", "complete", style, depth, "correct")
        val evaluable = pilot.sum("ast_to_source", "complete", style, depth, "model_evaluable")
        s"<td${if depth == "8" then " class=\"focus-cell\"" else ""}>$correct/$evaluable</td>"
      }.mkString
      s"<tr><th scope=\"row\">${h(labels(style))}</th>$cells</tr>"
    }.mkString
    val syntax = styles.map { style =>
      val opener = if style == "braces" then "area n_abcdefgh {" else "area n_abcdefgh"
      val closer = style match
        case "braces" => "}"
        case "generic_end" => "end"
        case "typed_end" => "end area"
        case "named_end" => "end area n_abcdefgh"
        case "padded_end" => "end junk z_aaaaaaaa"
      s"<article class=\"syntax-card\"><h3>${h(labels(style))}</h3><pre><code>${h(opener + "\nlet x_a 1739\n" + closer)}</code></pre></article>"
    }.mkString
    val glossary = Vector(
      "scope_lookup" -> "T1 · prefix の最後の probe で見える変数値を、整数ひとつで答える。",
      "active_stack" -> "T2 · probe の時点で開いている scope 名を、外側から内側への JSON 配列で答える。",
      "ast_to_source" -> "T3 · 中立的な parent/order 付き AST 表から、全ブロックを閉じたプログラムを生成する。",
      "source_to_ast" -> "P2 の追加課題 · 全文のプログラムを読み、scope・kind・name・順序・値・nop を入れ子の JSON AST に復元する。")
      .map((task, text) => s"<div class=\"task\"><code>${h(task)}</code><p>${h(text)}</p></div>").mkString
    val protocolRows = Vector(pilot, main).map { run =>
      s"<tr><th scope=\"row\">${if run.name == "pilot" then "P1 pilot" else "Frozen main"}</th>" +
        s"<td><code>${h(protocolScalar(run.protocol, "protocolHash"))}</code></td>" +
        s"<td><code>${h(protocolScalar(run.protocol, "sourceHash"))}</code></td>" +
        s"<td>${source(run.name, "protocol.json", "protocol.json")}</td></tr>"
    }.mkString
    val promptLink = "supporting/pilot-named-end-ast-to-source-prompt.txt"
    val prompt =
      if Files.isRegularFile(input.resolve(promptLink)) then
        val raw = Files.readString(input.resolve(promptLink), UTF_8)
        val grammar = raw.split("\nSYNTAX\n", 2).lift(1).flatMap(_.split("\nEXAMPLES\n", 2).headOption)
        grammar.map(g => detail("実際の D / natural の文法説明", s"<pre><code>${h(g.trim)}</code></pre>"))
          .getOrElse("") + s"<p>${link(promptLink, "実際の文法・固定8例・テストを含む保存済み全文 prompt")}" +
          s" ／ ${link("supporting/pilot-named-end-ast-to-source-request.json", "保存済み canonical logical request")}</p>"
      else "<p>文法と固定8例は保存済み protocol / report を参照。</p>"

    s"""<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="未知の小言語の構造をAIが扱う実験。保存済みP1 pilot、途中の本実験、未実行の全文parsing/generationを区別した再現可能なレポート。">
<title>Syntax locality — AIは構造をどこまで扱えるか</title>
<style>$css</style>
</head>
<body>
<a class="skip" href="#question">本文へ</a>
<header class="hero">
<div class="wrap">
<p class="eyebrow">SYNTAX LOCALITY / SAVED-ARTIFACT REPORT</p>
<h1>未知の小言語で、AIは<br>どこまで構造を扱えるか。</h1>
<p class="lead">文法を明示し、8つの例を渡す。閉じ方だけが異なる5つの表記で、同じ構造を読み取り・生成できるかを比べる。</p>
<div class="hero-facts"><div><span class="big">${percent(named.number("correct"), named.number("model_evaluable"))}</span><span>P1 · named end の全文生成<br>${named.number("correct")}/${named.number("model_evaluable")} 正解</span></div><div><span class="big">24 / 24</span><span>P1 · depth 8 の named end<br>generic end は 0 / 24</span></div><div><span class="big">未実行</span><span>P2 · 全文から AST への parsing<br>成功率はまだ測っていない</span></div></div>
<p class="hero-source">出典: ${source("pilot", "summary.csv", "P1 summary.csv")}。P1 は探索的 pilot。全文 parsing の結果としては扱わない。</p>
</div>
</header>
<nav aria-label="レポートの章"><div class="wrap"><a href="#question">問いと課題</a><a href="#results">測定結果</a><a href="#syntax">5つの表記</a><a href="#method">計測方法</a><a href="#status">実行状態</a><a href="#artifacts">資料・再現性</a></div></nav>
<main class="wrap">
<section id="question">
<p class="section-label">01 / QUESTION</p><h2>「読めた」は、何を答えたかで分ける。</h2>
<p>ここでの「未知」は、課題内で説明された小さな文法を指す。モデルの学習履歴に完全に存在しなかったことは確認できない。自然なキーワードと nonce（固定された無意味語）を使い分けても、既知の言語からの転移や tokenization は残る。</p>
<div class="tasks">$glossary</div>
<aside class="callout"><strong>元の読み取り実験は prefix 課題。</strong>入力は probe で止まる。<code>before_close</code> は閉じる前、<code>after_close</code> は閉じた後を観測する。末尾の開いたブロックは意図した入力であり、全文を AST に復元する試験ではない。ユーザーの問いに合わせた全文 parsing は、別の P2 として追加した。${link("docs/protocol.md", "元の protocol")} / ${link("docs/full-program-structures.md", "P2 設計")}</aside>
</section>
<section id="results">
<p class="section-label">02 / RESULTS</p><h2>生成で大きく分かれた、depth 8。</h2>
<p>P1 の全文生成では、名前付きの閉じラベル D が <strong>71/72 (${percent(71,72)})</strong> 正解。B の一般的な <code>end</code> は <strong>${generic.number("correct")}/${generic.number("model_evaluable")}</strong>。D の72応答はすべて構文として成立し、1件は AST が違った。この有限の pilot では、D の生成結果が強い。${source("pilot", "summary.csv", "集計")}</p>
<div class="two-columns"><div class="table-scroll"><table><caption>P1 · T3 厳密な全文生成 / 各 depth 24応答</caption><thead><tr><th scope="col">Style</th><th scope="col">depth 2</th><th scope="col">depth 4</th><th scope="col">depth 8</th></tr></thead><tbody>$depthRows</tbody></table></div><div><p>depth 8 で B は 0/24、E は 1/24、D は24/24。B と E はそれぞれ23件で、最初の構文エラーが <code>unclosed_scope</code> だった。</p><p>これらは provider の status が completed の応答。不足した閉じ行は、出力上限による打ち切りと同じ意味ではない。内部の reasoning の原因は測っていない。${link("docs/pilot-interpretation.md", "失敗分類と解釈")}</p></div></div>
<h3>条件を切り替えて、分母も見る。</h3>
<p class="muted">下の表は保存済み summary.csv の重複しないセルを合計した記述集計。割合は正解数 / 評価可能数の比。選択した部分群の信頼区間を新しく計算しない。</p>
<form class="filters" aria-label="結果の絞り込み">
<label>Run<select id="run"><option value="pilot">P1 pilot · 完了</option><option value="main">Frozen main · 途中</option></select></label>
<label>Task<select id="task"><option value="ast_to_source">ast_to_source · 全文生成</option><option value="scope_lookup">scope_lookup · prefix 値</option><option value="active_stack">active_stack · prefix stack</option></select></label>
<label>View<select id="view"><option value="complete">complete</option></select></label>
<label>Lexicon<select id="lex"><option value="ALL">natural + nonce</option><option value="natural">natural</option><option value="nonce">nonce</option></select></label>
<label>Depth<select id="depth"><option value="ALL">全 depth</option></select></label>
<label>Filler<select id="filler"><option value="ALL">全 filler</option></select></label>
</form>
<p id="selection-status" class="selection-status" role="status" aria-live="polite">P1 pilot · ast_to_source / complete / natural + nonce / 全 depth / 全 filler</p>
<div id="accuracy-chart" class="accuracy-chart" role="img" aria-label="P1 全文生成の各表記の正解率"></div>
<div class="table-scroll"><table id="results-table"><caption>正解と実行状況 · CI を伴わない条件別集計</caption><thead><tr><th scope="col">Style</th><th scope="col">正解 / 評価可能</th><th scope="col">正解率</th><th scope="col">計画</th><th scope="col">dispatch</th><th scope="col">terminal</th><th scope="col">infra missing</th><th scope="col">未 dispatch</th></tr></thead><tbody>$initialRows</tbody></table></div>
<noscript><p>JavaScript が無効なため、表は P1 の全 depth / 全 filler の全文生成を表示している。他の条件は ${source("pilot", "summary.csv", "CSV")} を参照。</p></noscript>
<h3>保存済みの paired comparison。</h3>
<p>どれも D−B、P1 の探索的比較。36 structural families をクラスターとして、depth × filler 内で10,000回の bootstrap（seed 20261005）。natural / nonce を family 内で平均する。複数の結果を見たことへの補正はしていない。${source("pilot", "paired-comparisons.csv", "元の比較表")}</p>
<div class="table-scroll"><table><caption>P1 · D−B / 元の保存済み 95% CI（単位: percentage points）</caption><thead><tr><th scope="col">Task / view</th><th scope="col">Matched families</th><th scope="col">D−B</th><th scope="col">95% CI</th><th scope="col">CI status</th></tr></thead><tbody>$comparisonRows</tbody></table></div>
<p>T1 の区間はゼロを含む。T3 の生成差と、confirmatory な読み取り仮説の成立は分けて評価する。before-close の B/D は天井で差0、退化した区間 [0,0] になり、一般的な同等性を示すものではない。</p>
</section>
<section id="syntax">
<p class="section-label">03 / SYNTAX</p><h2>同じ AST、異なる閉じ方。</h2><p>次は natural lexicon の最小例。body は同じで、A だけ開き行にも <code>{</code> が付く。E の固定 suffix は長さを増すが、scope の種類や名前は伝えない。インデントには意味がない。</p>
<div class="syntax-grid">$syntax</div>
<p>本試行では、対応する条件間の AST・識別子・値・文の順序・語彙対応と few-shot の内容・順序を保持する。<code>unit</code> / <code>func</code> / <code>area</code> は全て同じ scope 意味を持つ。nonce は8種類の固定 lexicon を割り当て、自然語条件と等重みで扱う。</p>
$prompt
</section>
<section id="method">
<p class="section-label">04 / MEASUREMENT</p><h2>応答全体を、保存された gold と照合する。</h2>
<div class="two-columns"><div><h3>厳密な採点</h3><p>T1 は応答全体がひとつの10進整数で、見える値に一致すること。T2 は文字列だけの JSON 配列で、開いている scope とその順序が一致すること。T3 は生成全文を parser で受理し、kind・name・順序・変数・値・nop payload が AST と一致すること。</p><p>説明や Markdown fences は strict score の失敗。incomplete / refusal もモデル評価可能な失敗に含める。API / transport / 結果不明などは infrastructure missing として別に扱う。再試行で誤答を修正したり、best-of-N を取ったりしない。</p></div><div><h3>独立性と制約</h3><p>再帰 AST oracle と明示スタックの event oracle は独立した実装。監査で両者と5表記の gold 一致を確認する。テストに通ることは全入力の正しさの証明ではない。</p><p>統計の標本クラスターは structural family。5つのレンダリング、natural / nonce、replicate を別々の独立標本として数えない。task の違い、pilot と main、変更後の P2 はプールしない。</p></div></div>
<p>文法は明示し、固定8例を同じ順番で提示した。モデルは <code>${h(protocolScalar(pilot.protocol, "model"))}</code>、reasoning effort は <code>${h(protocolScalar(pilot.protocol, "reasoningEffort"))}</code>。reading の output cap は8192、generation は16384。これらは実際のプロトコル条件であり、一般のプログラム言語すべてへの能力判定ではない。${link("docs/protocol.md", "採点・実験 protocol")} / ${link("docs/limitations.md", "limitations")}</p>
</section>
<section id="status">
<p class="section-label">05 / RUN STATUS</p><h2>完了した測定と、まだ測れていない部分。</h2>
<div class="status-grid"><article><span class="pill complete">P1 / COMPLETE</span><h3>探索的 pilot</h3><p><strong>1,800/1,800</strong> terminal、すべて評価可能。<strong>1,622</strong> 正解（${percent(1622,1800)}）。失敗も含めて保存した。synthetic_mock=false。</p><p>${source("pilot", "report.md", "保存済み Markdown report")}</p></article><article><span class="pill partial">MAIN / SNAPSHOT</span><h3>元の frozen main</h3><p>${h(mainNotice)}</p><p>dispatch ${comma(main.total.number("dispatched"))}、infrastructure missing ${comma(main.total.number("infrastructure_missing"))}。CSV の未 dispatch ${comma(main.total.number("not_dispatched"))} は、既に terminal 化した未送信と、未着手の計画試行の合計。</p><p>${source("main", "report.md", "保存済み途中 report")}</p></article><article><span class="pill pending">P2 / UNEXECUTED</span><h3>全文 parsing ↔ generation</h3><p><strong>48 families / 960 generations</strong> の別 pilot を設計。全文 <code>source_to_ast</code> と <code>ast_to_source</code> を同じ構造条件で比べる。</p><p>$p2VerificationText</p><p>${link("docs/full-program-structures.md", "P2 設計")} / ${link("supporting/full-program-pilot.json", "予定 config")}</p></article></div>
<aside class="callout"><strong>使用量と中断。</strong>P1 の既知使用量は ${comma(pilot.total.number("unique_total_tokens_known"))} tokens。main は ${comma(main.total.number("unique_total_tokens_known"))} known tokens。$reservation これらは billing の確定額や無料 quota の証拠ではない。${source("main", "summary.csv", "使用量 CSV")}</aside>
<p>main は全5,120試行を終えた測定ではなく、途中時点の数値。途中の有利な差を理由に止めたり、プランを変えたりしていない。元の固定 protocol を保持し、P2 を別プロトコルとして扱う。</p>
<p>P2 の中立表現は、parsing 側が入れ子 JSON、generation 側が parent/order 表で異なる。完全に同一の表現を反転した課題ではなく、結果は方向別に報告する。</p>
</section>
<section id="artifacts">
<p class="section-label">06 / ARTIFACTS</p><h2>数値から、保存資料に戻れる。</h2>
<p>この HTML は公開用に選んだ保存資料だけから生成した。CSV は元の Scala 採点・統計処理の出力で、HTML 作成時には再採点・再 bootstrap していない。以下は実際にコピーした各ファイルの SHA-256。</p>
<div class="table-scroll"><table class="protocol-table"><caption>実験 protocol と source の識別子</caption><thead><tr><th scope="col">Run</th><th scope="col">Protocol hash</th><th scope="col">Source hash</th><th scope="col">Download</th></tr></thead><tbody>$protocolRows</tbody></table></div>
<p><strong>Pilot v1 の記録制限:</strong>完全な canonical logical request は保存したが、実際の transport wire の JSON key order を byte-for-byte では記録していない。再構成した body を当時の raw wire と呼ばない。source v1 の採点と応答は維持し、変更後の main と統合していない。${link("docs/pilot-interpretation.md", "provenance の説明")}</p>
${detail("公開資料のハッシュとダウンロード", s"<div class=\"table-scroll\"><table class=\"artifact-table\"><caption>Public input artifacts / SHA-256</caption><thead><tr><th scope=\"col\">File</th><th scope=\"col\">SHA-256</th></tr></thead><tbody>$artifacts</tbody></table></div>")}
<p class="muted">Input manifest SHA-256: <code class="hash">$fingerprint</code>。ローカルの絶対パス・秘密鍵・実行中の API 接続は HTML に含めない。</p>
<p><a href="build-provenance.json" download>公開 build の検証状態と workflow 識別子</a>。data/status.json は資料選定時点の状態で、別 job の検証成功とは時点を区別する。</p>
</section>
</main>
<footer><div class="wrap"><p>Syntax locality ICL experiment · Scala 3.3.8 / JDK 21 / sbt 1.10.7</p><p>Completed pilot ≠ completed main ≠ measured whole-program parsing.</p></div></footer>
<script>const DATA = $dataJs;
$browserScript
</script>
</body>
</html>
"""

  private def tableRow(style: String, correct: Long, evaluable: Long, planned: Long, dispatched: Long,
    terminal: Long, missing: Long, notDispatched: Long): String =
    s"<tr${if style == "named_end" then " class=\"named-row\"" else ""}><th scope=\"row\">${h(labels(style))}</th>" +
      s"<td>$correct / $evaluable</td><td>${percent(correct,evaluable)}</td><td>$planned</td><td>$dispatched</td>" +
      s"<td>$terminal</td><td>$missing</td><td>$notDispatched</td></tr>"

  private val css = """
:root{--navy:#10243e;--ink:#182c45;--blue:#3877b9;--orange:#bd5a24;--paper:#fafbfc;--muted:#586a7d;--line:#dce3eb;--pale:#edf3f9}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:5rem}body{margin:0;background:var(--paper);color:var(--ink);font-family:system-ui,-apple-system,"Segoe UI","Yu Gothic",Meiryo,sans-serif;line-height:1.85;font-size:16px}a{color:#175b9a;text-underline-offset:3px}a:hover{color:var(--orange)}a:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid #e19955;outline-offset:4px}.wrap{max-width:1150px;margin:0 auto;padding:0 30px}.skip{position:absolute;left:10px;top:-100px;z-index:10;background:white;padding:12px}.skip:focus{top:10px}.hero{background:var(--navy);color:#f6f9fc;padding:64px 0 36px}.eyebrow,.section-label{font-size:12px;letter-spacing:.16em;font-weight:700}.eyebrow{color:#9dc5ed;margin:0 0 16px}.hero h1{font-size:clamp(30px,4.5vw,53px);line-height:1.5;letter-spacing:-.02em;margin:0 0 20px;font-weight:750}.lead{max-width:800px;color:#d2e0ee;font-size:18px}.hero-facts{display:grid;grid-template-columns:1fr 1fr 1fr;gap:28px;margin:36px 0 24px}.hero-facts>div{border-top:1px solid #49617c;padding-top:20px;display:flex;flex-direction:column}.hero-facts .big{font-size:38px;line-height:1.2;letter-spacing:-.03em;font-variant-numeric:tabular-nums;margin-bottom:12px}.hero-facts>div:first-child .big{color:#f4b078}.hero-facts>div>span:last-child{font-size:14px;color:#d2e0ee}.hero-source{font-size:12px;color:#b5c8dc}.hero a{color:#b9d9fa}nav{background:#fff;border-bottom:1px solid var(--line);position:sticky;top:0;z-index:2}nav .wrap{display:flex;gap:26px;overflow-x:auto;white-space:nowrap;padding-top:13px;padding-bottom:13px}nav a{font-size:13px;font-weight:700;text-decoration:none}main section{padding:48px 0;border-bottom:1px solid var(--line);scroll-margin-top:60px}.section-label{color:var(--blue);margin:0 0 8px}h2{font-size:clamp(23px,3vw,30px);line-height:1.6;margin:0 0 20px;letter-spacing:-.01em}h3{font-size:18px;line-height:1.6;margin:26px 0 12px}p{margin:0 0 18px}code{font-family:ui-monospace,SFMono-Regular,Consolas,"Liberation Mono",monospace;font-size:.88em;background:#edf1f5;border-radius:3px;padding:.1em .3em;overflow-wrap:anywhere}.hero code{background:#203b59}.muted{color:var(--muted);font-size:14px}.tasks{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:24px 0}.task{border-left:3px solid #88a8c9;background:var(--pale);padding:18px 20px}.task p{margin:10px 0 0;font-size:14px}.callout{background:#fff4ea;border-left:3px solid var(--orange);padding:20px 23px;margin:24px 0;font-size:14px}.callout strong{color:#924318}.two-columns{display:grid;grid-template-columns:1.15fr 1fr;gap:32px;margin:24px 0}.two-columns>div>h3:first-child{margin-top:0}.table-scroll{overflow-x:auto;border:1px solid var(--line);border-radius:3px;margin:18px 0 24px;background:#fff}table{border-collapse:collapse;width:100%;font-size:13px;font-variant-numeric:tabular-nums;text-align:left}caption{text-align:left;font-weight:650;color:var(--ink);padding:14px 16px;border-bottom:1px solid var(--line);background:#f3f6f9}th,td{padding:12px 14px;border-bottom:1px solid #e6ebf0;vertical-align:top;white-space:nowrap}thead th{font-size:12px;letter-spacing:.02em;color:#51647a;background:#fafbfc}tbody tr:last-child>*{border-bottom:0}tbody th{font-weight:600}.named-row,.focus-cell{background:#fff4e9}.filters{display:grid;grid-template-columns:repeat(6,minmax(100px,1fr));gap:14px;margin-top:20px}.filters label{font-size:12px;color:var(--muted);font-weight:650;display:flex;flex-direction:column;gap:7px}select{background:white;border:1px solid #b9c7d6;border-radius:3px;color:var(--ink);padding:10px 8px;font:inherit;min-width:0;font-size:12px}.selection-status{font-size:13px;margin:18px 0 14px;color:var(--muted)}.accuracy-chart{background:white;border:1px solid var(--line);padding:22px 24px;border-radius:3px}.bar-row{display:grid;grid-template-columns:135px minmax(60px,1fr) 140px;align-items:center;gap:14px;margin:12px 0;font-size:13px}.bar-track{background:#e8eef5;height:16px;position:relative;border-radius:2px}.bar-fill{background:var(--blue);height:100%;border-radius:2px}.bar-fill.named{background:var(--orange)}.bar-value{text-align:right;font-variant-numeric:tabular-nums}.bar-unmeasured{color:var(--muted);font-size:12px}.syntax-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:15px;margin:24px 0}.syntax-card{background:white;border:1px solid var(--line);padding:0 18px}.syntax-card h3{font-size:14px;margin:16px 0}.syntax-card:nth-child(4){border-top:3px solid var(--orange)}pre{font-size:12px;line-height:1.8;overflow:auto;padding:16px;background:#edf2f7}pre code{background:none;padding:0;overflow-wrap:normal}details{border:1px solid var(--line);border-radius:3px;background:white;margin:20px 0}summary{padding:16px 20px;font-size:14px;cursor:pointer;font-weight:650}details>p,details>pre{margin:0 20px 20px}details .table-scroll{margin:0;border-left:0;border-right:0}.status-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin:24px 0}.status-grid article{background:white;border:1px solid var(--line);padding:22px}.status-grid p{font-size:14px}.pill{display:inline-block;font-size:10px;letter-spacing:.07em;font-weight:750;border-radius:20px;padding:4px 10px;line-height:1.6}.complete{background:#e9f2f9;color:#215886}.partial{background:#fff0df;color:#9a4b17}.pending{background:#eef0f3;color:#5d6775}.status-grid h3{margin:14px 0}.protocol-table td,.protocol-table th{white-space:normal}.protocol-table code{font-size:10px;background:transparent;word-break:break-all}.hash{font-size:10px;word-break:break-all}.artifact-table td:first-child{white-space:normal}.artifact-table code{background:transparent}footer{background:var(--navy);color:#b4c7dc;padding:30px 0;font-size:12px}footer p{margin:6px 0}@media(max-width:900px){.filters{grid-template-columns:repeat(3,1fr)}.status-grid{grid-template-columns:1fr}.two-columns{grid-template-columns:1fr;gap:12px}.hero-facts{gap:18px}.hero-facts .big{font-size:30px}}@media(max-width:620px){.wrap{padding-left:20px;padding-right:20px}.hero{padding-top:38px}.lead{font-size:16px}.hero-facts{grid-template-columns:1fr;gap:12px}.hero-facts>div{display:grid;grid-template-columns:135px 1fr;gap:12px;align-items:center;padding-top:15px}.hero-facts .big{font-size:26px;margin:0}.tasks,.syntax-grid{grid-template-columns:1fr}.filters{grid-template-columns:repeat(2,1fr)}.bar-row{grid-template-columns:105px 1fr;gap:8px}.bar-value{grid-column:2;text-align:left;font-size:11px;margin-top:-7px}.accuracy-chart{padding:14px}main section{padding-top:35px;padding-bottom:35px}nav .wrap{gap:20px}th,td{padding:10px}}@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}@media print{nav,.filters{display:none}.hero{background:white;color:var(--ink);padding:10px 0}.hero p,.hero-facts>div>span:last-child{color:var(--muted)}.hero a{color:var(--blue)}.hero-facts .big{color:var(--ink)!important}.wrap{max-width:none;padding:0}.table-scroll{overflow:visible}main section{break-inside:avoid}footer{background:white;color:var(--muted)}}
"""

  private val browserScript = """
(() => {
  'use strict';
  const styles = ['braces','generic_end','typed_end','named_end','padded_end'];
  const labels = {'braces':'A · braces','generic_end':'B · generic end','typed_end':'C · typed end','named_end':'D · named end','padded_end':'E · padded end'};
  const fields = ['correct','model_evaluable','planned','dispatched','terminal','infrastructure_missing','not_dispatched'];
  const controls = Object.fromEntries(['run','task','view','lex','depth','filler'].map(id => [id,document.getElementById(id)]));
  const tbody = document.querySelector('#results-table tbody');
  const chart = document.getElementById('accuracy-chart');
  function options(control, values, allLabel) {
    const old = control.value;
    control.replaceChildren();
    if (allLabel) { const option=document.createElement('option'); option.value='ALL'; option.textContent=allLabel; control.append(option); }
    for (const value of values) { const option=document.createElement('option'); option.value=value; option.textContent=value; control.append(option); }
    if ([...control.options].some(option => option.value===old)) control.value=old;
  }
  function synchronize() {
    const rows=DATA[controls.run.value];
    options(controls.task,[...new Set(rows.map(row=>row.task))].sort(),null);
    const taskRows=rows.filter(row=>row.task===controls.task.value);
    options(controls.view,[...new Set(taskRows.map(row=>row.view))].sort(),null);
    const viewRows=taskRows.filter(row=>row.view===controls.view.value);
    options(controls.depth,[...new Set(viewRows.map(row=>row.depth))].sort((a,b)=>Number(a)-Number(b)),'全 depth');
    options(controls.filler,[...new Set(viewRows.map(row=>row.filler))].sort((a,b)=>Number(a)-Number(b)),'全 filler');
  }
  function render() {
    const choice=Object.fromEntries(Object.entries(controls).map(([id,control])=>[id,control.value]));
    const selected=DATA[choice.run].filter(row=>row.task===choice.task && row.view===choice.view &&
      (choice.lex==='ALL'||row.lexical_regime===choice.lex) && (choice.depth==='ALL'||row.depth===choice.depth) &&
      (choice.filler==='ALL'||row.filler===choice.filler));
    const runName=choice.run==='pilot'?'P1 pilot':'Frozen main · 途中の記述集計';
    document.getElementById('selection-status').textContent=[runName,choice.task,choice.view,choice.lex==='ALL'?'natural + nonce':choice.lex,choice.depth==='ALL'?'全 depth':'depth '+choice.depth,choice.filler==='ALL'?'全 filler':'filler '+choice.filler].join(' / ');
    tbody.replaceChildren(); chart.replaceChildren();
    let accessible=[];
    for (const style of styles) {
      const totals=Object.fromEntries(fields.map(key=>[key,0]));
      for (const row of selected.filter(row=>row.style===style)) for (const key of fields) totals[key]+=Number(row[key]);
      const accuracy=totals.model_evaluable===0?null:100*totals.correct/totals.model_evaluable;
      const percentage=accuracy===null?'NA':accuracy.toFixed(3)+'%';
      const tr=document.createElement('tr'); if(style==='named_end') tr.className='named-row';
      const values=[labels[style],totals.correct+' / '+totals.model_evaluable,percentage,totals.planned,totals.dispatched,totals.terminal,totals.infrastructure_missing,totals.not_dispatched];
      values.forEach((value,index)=>{const cell=document.createElement(index===0?'th':'td');if(index===0)cell.scope='row';cell.textContent=value;tr.append(cell);});
      tbody.append(tr);
      const row=document.createElement('div');row.className='bar-row';
      const label=document.createElement('span');label.textContent=labels[style];
      const track=document.createElement('div');track.className='bar-track';
      if(accuracy!==null){const fill=document.createElement('div');fill.className='bar-fill'+(style==='named_end'?' named':'');fill.style.width=accuracy+'%';track.append(fill);}
      else{const empty=document.createElement('span');empty.className='bar-unmeasured';empty.textContent='評価可能な応答なし';track.append(empty);}
      const value=document.createElement('span');value.className='bar-value';value.textContent=percentage+' · '+totals.correct+'/'+totals.model_evaluable;
      row.append(label,track,value);chart.append(row);accessible.push(labels[style]+': '+value.textContent);
    }
    chart.setAttribute('aria-label',accessible.join('。'));
  }
  for (const control of Object.values(controls)) control.addEventListener('change',()=>{synchronize();render();});
  synchronize();render();
})();
"""
